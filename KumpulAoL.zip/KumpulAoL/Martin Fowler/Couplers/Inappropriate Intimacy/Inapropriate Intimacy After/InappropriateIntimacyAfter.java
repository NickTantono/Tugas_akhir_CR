public class BankAccount {
    private String accountNumber;
    private double balance;
    private Customer owner;

    public BankAccount(String accountNumber, double balance, Customer owner) {
        this.accountNumber = accountNumber;
        this.balance = balance;
        this.owner = owner;
    }

    public void deposit(double amount) {
        balance += amount;
    }

    public void withdraw(double amount) {
        balance -= amount;
    }

    public void displayAccountInfo() {
        System.out.println("Account Number: " + accountNumber);
        System.out.println("Balance: $" + balance);
        System.out.println("Owner: " + owner.getName());
    }
}

public class Customer {
    private String name;
    private String address;

    public Customer(String name, String address) {
        this.name = name;
        this.address = address;
    }

    public String getName() {
        return name;
    }
}

    public Warrior(String name, Weapon weapon){
        this.name = name;
        this.weapon = weapon;
    }
    
    public String getName(){
        return name;
    }

    public void weaponType(){
        this.weapon.weapontype();
    }
}

public class Weapon {
	public String name;
    private String type;

    public Weapon(String name, String type){
        this.name = name;
        this.type = type;
    }

    public void weapontype(){
        System.out.println(type);
    }
}