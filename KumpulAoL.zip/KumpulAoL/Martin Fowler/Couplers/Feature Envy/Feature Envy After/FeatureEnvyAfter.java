public class ContactInfo {
    private String streetName;
    private String city;
    private String state;

    public ContactInfo(String streetName, String city, String state) {
        this.streetName = streetName;
        this.city = city;
        this.state = state;
    }

    public String getStreetName() {
        return streetName;
    }

    public String getCity() {
        return city;
    }

    public String getState() {
        return state;
    }

    public String getFullAddress() {
        return streetName + ";" + city + ";" + state;
    }
}

public class User {
    private ContactInfo contactInfo;

    public User(ContactInfo contactInfo) {
        this.contactInfo = contactInfo;
    }

    public String getFullAddress() {
        return contactInfo.getFullAddress();
    }
}