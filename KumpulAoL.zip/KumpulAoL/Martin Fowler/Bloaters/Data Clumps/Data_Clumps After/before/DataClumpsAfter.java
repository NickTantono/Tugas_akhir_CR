import java.util.Date;

public class RentalPeriod {
    private Date startDate;
    private Date endDate;

    public RentalPeriod(Date startDate, Date endDate) {
        this.startDate = startDate;
        this.endDate = endDate;
    }

    public Date getStartDate() {
        return startDate;
    }

    public Date getEndDate() {
        return endDate;
    }
}

public class Movie {
    private String movieName;
    private RentalPeriod rentalPeriod;
    
    public Movie(String movieName, RentalPeriod rentalPeriod) {
        this.movieName = movieName;
        this.rentalPeriod = rentalPeriod;
    }

    public String getMovieName() {
        return movieName;
    }

    public RentalPeriod getRentalPeriod() {
        return rentalPeriod;
    }
}
