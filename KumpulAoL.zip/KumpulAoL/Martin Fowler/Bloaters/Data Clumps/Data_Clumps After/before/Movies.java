package data_clumps.before;

import java.util.*;

public class Movies {
	private String movieName;
	private Date rentStart;
	private Date rentEnd;
	
	public Date getStart() {
		return rentStart;
	}
	
	public Date getEnd() {
		return rentEnd;
	}
}
