public class User {
    private String name;
    private String email;
    private Wallet wallet;

    public User(String name, String email, Wallet wallet) {
        this.name = name;
        this.email = email;
        this.wallet = wallet;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public Wallet getWallet() {
        return wallet;
    }
}