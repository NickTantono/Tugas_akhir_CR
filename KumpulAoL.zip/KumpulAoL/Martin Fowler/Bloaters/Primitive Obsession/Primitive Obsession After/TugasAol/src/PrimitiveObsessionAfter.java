public class Character {
    private String name;
    private CharacterClass charClass;
    private Weapon weapon;
    private Armor armor;
    
    public Character(String name, CharacterClass charClass, Weapon weapon, Armor armor) {
        this.name = name;
        this.charClass = charClass;
        this.weapon = weapon;
        this.armor = armor;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public CharacterClass getCharClass() {
        return charClass;
    }
    
    public void setCharClass(CharacterClass charClass) {
        this.charClass = charClass;
    }
    
    public Weapon getWeapon() {
        return weapon;
    }
    
    public void setWeapon(Weapon weapon) {
        this.weapon = weapon;
    }
    
    public Armor getArmor() {
        return armor;
    }
    
    public void setArmor(Armor armor) {
        this.armor = armor;
    }
}