package paralell_inheritance_hierarchies.before;

public interface Shape2D {
    float getWidth();
    void setWidth(float width);
    float getHeight();
    void setHeight(float height);
}

