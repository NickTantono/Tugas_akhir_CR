package paralell_inheritance_hierarchies.before;

public interface Shape {
	// Menambahkan method getArea() untuk mengembalikan luas bentuk geometri
    float getArea();
}