public class Calculator {
    public static void calculate(double num1, double num2, String operator) {
        double result;
        switch (operator) {
            case "+":
                result = num1 + num2;
                break;
            case "-":
                result = num1 - num2;
                break;
            case "*":
                result = num1 * num2;
                break;
            case "/":
                result = num1 / num2;
                break;
            case "%":
                result = num1 % num2;
                break;
            default:
                System.out.println("Invalid operator!");
                return;
        }
        System.out.println(result);
    }

    public static void main(String[] args) {
        Calculator.calculate(10, 5, "+"); // output: 15.0
        Calculator.calculate(10, 5, "-"); // output: 5.0
        Calculator.calculate(10, 5, "*"); // output: 50.0
        Calculator.calculate(10, 5, "/"); // output: 2.0
        Calculator.calculate(10, 5, "%"); // output: 0.0
        Calculator.calculate(10, 5, "$"); // output: Invalid operator!
    }
}