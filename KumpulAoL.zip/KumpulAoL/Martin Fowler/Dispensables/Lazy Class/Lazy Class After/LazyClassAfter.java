package Company;

public class Worker {
    private String workerName;
    private int workerSalary;

    public Worker(String workerName, int workerSalary) {
        this.workerName = workerName;
        this.workerSalary = workerSalary;
    }

    public String getName() {
        return workerName;
    }

    public int getSalary() {
        return workerSalary;
    }
}
