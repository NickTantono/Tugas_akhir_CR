package dead_code;

public class Clothes {
    protected String name;
    protected String size;
    protected int price;

    public Clothes(String name, String size, int price) {
        this.name = name;
        this.size = size;
        this.price = price;
    }

    public int getPrice() {
        return this.price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
}

package dead_code;

public class DiscountCalculator {
    public double setFinalPrice(int priceBefore) {
        double finalPrice = priceBefore;

        // Pada awal toko baju dibuka, diskon baju 20% hanya untuk pembayaran lebih dari 5000000
        if (priceBefore > 5000000) {
            finalPrice = priceBefore - (priceBefore * 0.2);
        } else {
            // Setelah toko baju lumayan lama berdiri, pengunjung semakin sedikit dan diskon baju itu 10% untuk semua item
            finalPrice = priceBefore - (priceBefore * 0.1);
        }

        return finalPrice;
    }
}