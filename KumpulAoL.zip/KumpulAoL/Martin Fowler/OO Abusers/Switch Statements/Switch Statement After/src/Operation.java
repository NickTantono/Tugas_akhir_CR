public interface Operation {
    void perform();

//    String pilihanOperasi(); --> pakai ini untuk mengerjakan jawaban.
}
