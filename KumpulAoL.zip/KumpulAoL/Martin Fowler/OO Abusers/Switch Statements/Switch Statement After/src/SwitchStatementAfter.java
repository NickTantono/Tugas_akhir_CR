private void calculateTotalPrice() {
    totalPrice = 0.0;
    for (Item item : items) {
        totalPrice += item.getPrice();
    }
}
public void addItem(Item item) {
    items.add(item);
    calculateTotalPrice();
}
public void removeItem(Item item) {
    items.remove(item);
    calculateTotalPrice();
}
