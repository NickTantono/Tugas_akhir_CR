public abstract class Operation {
    // ...
    public abstract String getPesanHasil();
}

public class Pembagian extends Operation {
    // ...
    @Override
    public String getPesanHasil() {
        return " dan hasilnya adalah ";
    }
}

public class Perkalian extends Operation {
    // ...
    @Override
    public String getPesanHasil() {
        return " dan hasilnya adalah ";
    }
}

// Implementasi metode getPesanHasil() pada kelas Pertambahan dan Pengurangan

public static void printPilihanOperasi(Operation operasi) {
    System.out.print("Anda memilih " + operasi.getClass().getSimpleName() + operasi.getPesanHasil());
}