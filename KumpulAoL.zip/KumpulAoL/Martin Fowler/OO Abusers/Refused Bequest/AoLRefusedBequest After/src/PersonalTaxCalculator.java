public class PersonalTaxCalculator {
    public double calculateTax(double income, double taxRate) {
        return income * taxRate;
    }
}