public class Mahasiswa {
    private String NIM;
	private String Email;
    private String NomorTelepon;
	
	public String getNIM() {
		return NIM;
	}
	//...
}
