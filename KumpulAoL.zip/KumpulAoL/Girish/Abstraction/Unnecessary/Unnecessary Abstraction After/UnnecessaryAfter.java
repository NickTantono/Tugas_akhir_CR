import java.awt.Color;
import javax.swing.JButton;

abstract class ColoredButton extends JButton {
    public ColoredButton(String text, Color backgroundColor) {
        super(text);
        this.setBackground(backgroundColor);
    }
}

public class BlueButton extends ColoredButton {
    public BlueButton(String text) {
        super(text, Color.BLUE);
    }
}

public class RedButton extends ColoredButton {
    public RedButton(String text) {
        super(text, Color.RED);
    }
}
