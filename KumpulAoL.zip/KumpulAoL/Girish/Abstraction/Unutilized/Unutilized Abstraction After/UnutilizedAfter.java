abstract class AbstractVehicle {
    abstract void model();
    abstract void color();
}

abstract class AbstractMotorcycle extends AbstractVehicle {
    abstract void cylinderCapacity();
}

class Mercedes extends AbstractVehicle {
    public void model() {
        System.out.println("e320");
    }

    public void color() {
        System.out.println("silver");
    }
}

class Ducati extends AbstractMotorcycle {
    public void model() {
        System.out.println("v4S");
    }

    public void color() {
        System.out.println("red");
    }

    public void cylinderCapacity() {
        System.out.println("1103cc");
    }
}
