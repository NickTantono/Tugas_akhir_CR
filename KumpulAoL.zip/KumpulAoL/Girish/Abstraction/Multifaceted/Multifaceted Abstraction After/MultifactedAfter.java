public class Rectangle {
    private int width;
    private int height;

    public Rectangle(int width, int height) {
        if (width <= 0 || height <= 0) {
            throw new IllegalArgumentException("Width and height must be greater than zero");
        }

        this.width = width;
        this.height = height;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public int area() {
        return width * height;
    }

    public int perimeter() {
        return 2 * (width + height);
    }

    public void print(String style) {
        style = style.toLowerCase();
        StringBuilder rectangleBuilder = new StringBuilder();

        switch (style) {
            case "full":
                for (int i = 0; i < height; i++) {
                    rectangleBuilder.append("*".repeat(width)).append("\n");
                }
                break;

            case "border":
                for (int i = 0; i < height; i++) {
                    for (int j = 0; j < width; j++) {
                        rectangleBuilder.append(j == 0 || j == width - 1 || i == 0 || i == height - 1 ? "*" : " ");
                    }
                    rectangleBuilder.append("\n");
                }
                break;

            default:
                System.out.println("Style not recognized");
                return;
        }

        System.out.print(rectangleBuilder.toString());
    }
}
