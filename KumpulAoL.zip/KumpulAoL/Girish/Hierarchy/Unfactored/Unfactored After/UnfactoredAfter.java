import java.util.ArrayList;
import java.util.List;

interface Employee {
    String getName();
    void addEmployee(Employee employee);
    List<Employee> getEmployees();
}

class EmployeeImpl implements Employee {
    private String name;
    private List<Employee> employees;

    public EmployeeImpl(String name) {
        this.name = name;
        this.employees = new ArrayList<>();
    }

    public void addEmployee(Employee employee) {
        employees.add(employee);
    }

    public List<Employee> getEmployees() {
        return employees;
    }

    public String getName() {
        return name;
    }
}
public class EmployeeHierarchyExample {
    public static void main(String[] args) {
        Employee ceo = new EmployeeImpl("John (CEO)");

        Employee manager1 = new EmployeeImpl("Mike (Manager 1)");
        Employee manager2 = new EmployeeImpl("Lisa (Manager 2)");

        Employee employee1 = new EmployeeImpl("Alice (Employee 1)");
        Employee employee2 = new EmployeeImpl("Bob (Employee 2)");
        Employee employee3 = new EmployeeImpl("Eve (Employee 3)");

        ceo.addEmployee(manager1);
        ceo.addEmployee(manager2);

        manager1.addEmployee(employee1);
        manager1.addEmployee(employee2);

        manager2.addEmployee(employee3);

        // Traversing the hierarchy
        printEmployeeHierarchy(ceo, 0);
    }

    public static void printEmployeeHierarchy(Employee employee, int level) {
        StringBuilder indentation = new StringBuilder();
        for (int i = 0; i < level; i++) {
            indentation.append("  "); // Two spaces per level
        }

        System.out.println(indentation + employee.getName());

        for (Employee subordinate : employee.getEmployees()) {
            printEmployeeHierarchy(subordinate, level + 1);
        }
    }
}
